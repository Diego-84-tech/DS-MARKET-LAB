DS Market Lab 0.1.0 — fictional paper-trading preview.
Upload this ZIP to Netlify, or extract and deploy its contents.
No build command, API key, account, Mac runner, or database is required.
No live data, AI forecasts, cloud sync, or real orders are connected.
Browser records are local to this device and URL; export important sessions.
Product icon / Home Screen install remains pending design approval.
